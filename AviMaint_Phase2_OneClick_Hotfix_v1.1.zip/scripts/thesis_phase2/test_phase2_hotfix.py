from __future__ import annotations

import csv
import tempfile
import unittest
from pathlib import Path

from . import common
from .final_protocol_robustness import (
    compare_clean_metrics,
    recover_verified_staging,
    spelling_noise,
    truncate,
)


class Phase2HotfixTests(unittest.TestCase):
    def test_truncation_is_deterministic(self) -> None:
        self.assertEqual(truncate("one two three four five", 0.40), "one two three")
        self.assertEqual(truncate("single", 0.90), "single")

    def test_spelling_noise_is_deterministic_and_preserves_digits(self) -> None:
        source = "num_4 intake ratio_20_80"
        first = spelling_noise(source, 0.10, "Q-1")
        second = spelling_noise(source, 0.10, "Q-1")
        self.assertEqual(first, second)
        self.assertEqual("".join(ch for ch in first if ch.isdigit()), "42080")

    def test_clean_metric_parity_accepts_exact_values(self) -> None:
        value = {name: 0.5 for name in (
            "hit_at_1", "hit_at_3", "hit_at_5", "mrr", "ndcg_at_5",
            "macro_action_family_recall", "answer_rate",
        )}
        value["queries"] = 828
        report = compare_clean_metrics(value, dict(value))
        self.assertTrue(report["passed"])

    def test_clean_metric_parity_fails_closed(self) -> None:
        value = {name: 0.5 for name in (
            "hit_at_1", "hit_at_3", "hit_at_5", "mrr", "ndcg_at_5",
            "macro_action_family_recall", "answer_rate",
        )}
        value["queries"] = 828
        changed = dict(value)
        changed["hit_at_1"] = 0.49
        with self.assertRaises(RuntimeError):
            compare_clean_metrics(changed, value)

    def test_checksum_manifest_detects_mutation(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            (root / "one.txt").write_text("frozen\n", encoding="utf-8")
            common.write_checksum_manifest(root)
            self.assertEqual(common.verify_checksum_manifest(root)["files_checked"], 1)
            (root / "one.txt").write_text("changed\n", encoding="utf-8")
            with self.assertRaises(RuntimeError):
                common.verify_checksum_manifest(root)

    def test_verified_staging_is_atomically_recovered(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            stage = root / "result.staging"
            output = root / "result"
            identity = {"frozen_input": "sha256-example"}
            stage.mkdir()
            common.atomic_json(stage / "RUN_MANIFEST.json", {
                "input_identity": identity,
                "clean_parity": {"passed": True},
            })
            (stage / "result.txt").write_text("complete\n", encoding="utf-8")
            common.write_checksum_manifest(stage)
            self.assertTrue(recover_verified_staging(stage, output, identity))
            self.assertFalse(stage.exists())
            self.assertEqual((output / "result.txt").read_text(encoding="utf-8"), "complete\n")

    def test_prediction_population_and_identity(self) -> None:
        with tempfile.TemporaryDirectory() as name:
            path = Path(name) / "test_raw.csv"
            ids = {f"id-{index}" for index in range(common.EXPECTED_TEST_RECORDS)}
            fields = [
                "example_id", "split", "system", "raw_text", "reference_text",
                "candidate_text", "prediction_text", "protected_tokens_preserved",
            ]
            with path.open("w", encoding="utf-8", newline="") as target:
                writer = csv.DictWriter(target, fieldnames=fields)
                writer.writeheader()
                for ident in sorted(ids):
                    writer.writerow({
                        "example_id": ident, "split": "test", "system": "raw",
                        "raw_text": "raw", "reference_text": "reference",
                        "candidate_text": "raw", "prediction_text": "raw",
                        "protected_tokens_preserved": "True",
                    })
            report = common.verify_prediction_csv(path, "raw", ids)
            self.assertEqual(report["records"], common.EXPECTED_TEST_RECORDS)


if __name__ == "__main__":
    unittest.main()
