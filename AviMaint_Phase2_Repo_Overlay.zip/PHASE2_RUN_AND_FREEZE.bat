@echo off
setlocal
set "MODE=%~1"
if "%MODE%"=="" set "MODE=SAFE"

if /I not "%MODE%"=="SAFE" if /I not "%MODE%"=="CONFIRM_TEST" (
  echo Usage: PHASE2_RUN_AND_FREEZE.bat [SAFE^|CONFIRM_TEST]
  echo.
  echo SAFE reuses completed outputs and never opens the missing normalization TEST.
  echo CONFIRM_TEST permits the existing one-time 741-record normalization TEST runner.
  exit /b 2
)

pushd "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\phase2\phase2_orchestrator.ps1" -Mode "%MODE%"
set "RESULT=%ERRORLEVEL%"
popd

if not "%RESULT%"=="0" pause
exit /b %RESULT%
