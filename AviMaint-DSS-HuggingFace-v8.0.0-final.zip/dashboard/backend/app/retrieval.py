from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from difflib import SequenceMatcher

import numpy as np
from rank_bm25 import BM25Okapi

from .calibration import AgreementCalibrator
from .data_store import DataStore
from .settings import Settings
from .terminology import (
    canonical_component,
    canonical_problem_key,
    find_components,
    find_locations,
    issue_family,
    looks_truncated,
    normalize_query_for_display,
)


_TOKEN = re.compile(r"[a-z0-9_]+")


def tokenize(value: str) -> list[str]:
    return _TOKEN.findall(str(value or "").lower())


@dataclass(frozen=True)
class Hit:
    idx: int
    score: float
    raw_score: float


class SelectiveRetriever:
    def __init__(self, store: DataStore, settings: Settings, calibrator: AgreementCalibrator):
        self.store = store
        self.settings = settings
        self.calibrator = calibrator
        self.docs = store.train["problem_norm"].astype(str).tolist()
        self.bm25 = BM25Okapi([tokenize(value) for value in self.docs])

    def search(self, query_key: str, top_k: int | None = None) -> list[Hit]:
        depth = int(top_k or self.settings.retrieval_depth)
        raw = np.asarray(self.bm25.get_scores(tokenize(query_key)), dtype=float)
        minimum = float(raw.min()) if raw.size else 0.0
        maximum = float(raw.max()) if raw.size else 0.0
        scores = (raw - minimum) / (maximum - minimum) if maximum - minimum > 1e-12 else np.zeros_like(raw)
        hits: list[Hit] = []
        used_clusters: set[str] = set()
        for idx in np.argsort(-scores):
            cluster = str(self.store.train.iloc[int(idx)].cluster_id)
            if cluster in used_clusters:
                continue
            used_clusters.add(cluster)
            hits.append(Hit(int(idx), float(scores[idx]), float(raw[idx])))
            if len(hits) >= depth:
                break
        return hits

    @staticmethod
    def _case(row, score: float) -> dict:
        return {
            "ident": str(row.ident),
            "problem": str(row.problem),
            "problem_raw": str(row.problem_raw),
            "problem_may_be_truncated": looks_truncated(str(row.problem)),
            "action": str(row.action),
            "action_raw": str(row.action_raw),
            "action_may_be_truncated": looks_truncated(str(row.action)),
            "action_family": str(row.action_family),
            "outcome": str(row.outcome),
            "cluster_id": str(row.cluster_id),
            "score": round(float(score), 8),
            "text_score": round(float(score), 8),
            "structure_score": 0.0,
            "channels": {"canonical_bm25": round(float(score), 8)},
        }

    @staticmethod
    def _distinct_clusters(examples: list[dict], limit: int) -> list[dict]:
        selected = []
        used = set()
        for example in examples:
            cluster = example["cluster_id"]
            if cluster in used:
                continue
            used.add(cluster)
            selected.append(example)
            if len(selected) >= limit:
                break
        return selected

    @staticmethod
    def _anchor(candidate: list[str], query: list[str], *, component: bool) -> str:
        transform = canonical_component if component else lambda value: str(value).strip().lower()
        candidate_values = {transform(value) for value in candidate if transform(value)}
        query_values = {transform(value) for value in query if transform(value)}
        selected = sorted(candidate_values & query_values) or sorted(candidate_values)
        return " / ".join(selected[:3]) if selected else "(unspecified)"

    def _aggregate(self, hits: list[Hit], query_components: list[str], query_faults: list[str]) -> dict:
        families: dict[str, dict] = {}
        negative: list[dict] = []
        expanded_seen: set[int] = set()
        for hit in hits:
            cluster = str(self.store.train.iloc[hit.idx].cluster_id)
            for idx in self.store.cluster_members.get(cluster, [hit.idx]):
                if idx in expanded_seen:
                    continue
                expanded_seen.add(idx)
                row = self.store.train.iloc[idx]
                family = str(row.action_family)
                outcome = str(row.outcome)
                example = self._case(row, hit.score)
                if outcome in {"negative", "mixed"}:
                    negative.append(example)
                    continue
                if family == "Other":
                    continue
                bucket = families.setdefault(family, {"clusters": {}, "outcomes": {}, "examples": [], "patterns": {}})
                bucket["clusters"][cluster] = max(bucket["clusters"].get(cluster, 0.0), hit.score)
                bucket["outcomes"].setdefault(outcome, set()).add(cluster)
                bucket["examples"].append(example)
                component = self._anchor(row.components, query_components, component=True)
                fault = self._anchor(row.faults, query_faults, component=False)
                pattern_key = f"{family}|{component}|{fault}"
                pattern = bucket["patterns"].setdefault(pattern_key, {"clusters": {}, "examples": [], "outcomes": {}})
                pattern["clusters"][cluster] = max(pattern["clusters"].get(cluster, 0.0), hit.score)
                pattern["examples"].append(example)
                pattern["outcomes"].setdefault(outcome, set()).add(cluster)

        rows = []
        for family, bucket in families.items():
            support = len(bucket["clusters"])
            prior = max(self.store.family_priors.get(family, 0.0), 1e-12)
            rows.append({
                "family": family,
                "support_clusters": support,
                "case_count": len(bucket["examples"]),
                "score_sum": float(sum(bucket["clusters"].values())),
                "prior": prior,
                "adjusted_support": support / (prior ** self.settings.selected_tau),
                "outcome_positive": len(bucket["outcomes"].get("positive", set())),
                "outcome_unknown": len(bucket["outcomes"].get("unknown", set())),
                "outcome_negative": 0,
                "examples": self._distinct_clusters(
                    sorted(bucket["examples"], key=lambda item: (-item["score"], item["ident"])), 8
                ),
                "patterns": bucket["patterns"],
            })
        rows.sort(key=lambda item: (-item["adjusted_support"], -item["score_sum"], -item["support_clusters"], -item["outcome_positive"], item["family"]))
        top = rows[0]["adjusted_support"] if rows else 0.0
        second = rows[1]["adjusted_support"] if len(rows) > 1 else 0.0
        return {
            "families": rows,
            "negative": sorted(negative, key=lambda item: (-item["score"], item["ident"])),
            "family_margin": float(top - second),
        }

    def recommend(self, query: str, top_k: int = 50) -> dict:
        query = str(query or "").strip()
        query_display = normalize_query_for_display(query)
        query_key = canonical_problem_key(query_display)
        query_components = find_components(query_display)
        query_fault = issue_family(query_display)
        query_faults = [query_fault] if query_fault else []
        query_locations = find_locations(query_display)
        query_entities = (
            [{"type": "MAINT_ITEM", "text": value, "score": 1.0} for value in query_components]
            + [{"type": "FAULT", "text": value, "score": 1.0} for value in query_faults]
            + [{"type": "LOC", "text": value, "score": 1.0} for value in query_locations]
        )
        hits = self.search(query_key, min(max(int(top_k), 5), 100))
        evidence = self._aggregate(hits, query_components, query_faults)
        nearest = [self._case(self.store.train.iloc[hit.idx], hit.score) for hit in hits[:10]]
        families = evidence["families"]
        primary = families[0] if families else None
        support = int(primary["support_clusters"]) if primary else 0
        top_score = hits[0].score if hits else 0.0
        second_score = hits[1].score if len(hits) > 1 else 0.0
        retrieval_margin = float(top_score - second_score)
        exact = any(self.docs[hit.idx] == query_key for hit in hits)
        near = any(SequenceMatcher(None, query_key, self.docs[hit.idx]).ratio() >= 0.87 for hit in hits[:10])
        anchor_overlap = False
        if query_components and query_faults:
            for hit in hits[:10]:
                row = self.store.train.iloc[hit.idx]
                if set(query_components) & set(row.components) and set(query_faults) & set(row.faults):
                    anchor_overlap = True
                    break
        rung = "A" if exact else "B" if near else "C" if anchor_overlap else "D"
        support_tier = "strong" if support >= 3 else "moderate" if support == 2 else "limited" if support == 1 else "nearest_cases_only"
        if support_tier == "nearest_cases_only" or rung == "D":
            badge = "exploratory" if primary else "abstain"
        elif rung == "C" and support_tier != "limited":
            badge = "exploratory"
        else:
            badge = support_tier
        component_label = query_components[0] if query_components else "reported component"
        family_label = primary["family"] if primary else ""
        statement = (
            f"Historical cases most often recorded {family_label.lower()} actions for the {component_label}."
            if primary else ""
        )
        strategies = []
        for index, family in enumerate(families):
            strategies.append({
                "family": family["family"],
                "sentence": f"Review the recorded {family['family'].lower()} examples for the {component_label}.",
                "meaning": f"Observed in {family['support_clusters']} independent evidence cluster(s); this is historical evidence, not an instruction.",
                "support_clusters": family["support_clusters"],
                "case_count": family["case_count"],
                "outcome_positive": family["outcome_positive"],
                "outcome_negative": family["outcome_negative"],
                "outcome_unknown": family["outcome_unknown"],
                "examples": [
                    {
                        "ident": example["ident"],
                        "action": example["action"],
                        "outcome": example["outcome"],
                        "source_may_be_truncated": example["action_may_be_truncated"],
                    }
                    for example in family["examples"][:5]
                ],
                "is_primary": index == 0,
                "tier": "single_case" if family["support_clusters"] == 1 else "corroborated",
            })
        recommended = primary["examples"][:10] if primary else []
        agreement = self.calibrator.predict(top_score, retrieval_margin, support) if primary else None
        coverage_denominator = max(1, len(query_components) + len(query_faults))
        if hits and (query_components or query_faults):
            top_row = self.store.train.iloc[hits[0].idx]
            matched = len(set(query_components) & set(top_row.components)) + len(set(query_faults) & set(top_row.faults))
            anchor_coverage = matched / coverage_denominator
        else:
            anchor_coverage = 0.0
        return {
            "query": query,
            "components": query_components,
            "faults": query_faults,
            "badge": badge,
            "lens": "problem_only_selective_history",
            "headline_action": family_label,
            "headline_reason": f"Ranked with the frozen tau={self.settings.selected_tau:.2f} cluster vote; {support} independent supporting cluster(s)." if primary else "No eligible recorded action family was found.",
            "support_clusters": support,
            "structured_sentence": statement,
            "strategies": strategies,
            "recommended_cases": recommended,
            "alternatives": strategies[1:],
            "nearest_cases": nearest,
            "negative_evidence": evidence["negative"][:10],
            "structure_source": "selective_query_adapter",
            "entities": query_entities,
            "relations": [],
            "family_evidence_margin": evidence["family_margin"],
            "retrieval_margin": retrieval_margin,
            "anchor_coverage": anchor_coverage,
            "abstain": not bool(primary),
            "evidence_family": family_label,
            "base_top_score": top_score,
            "evidence_tier": {"A": "exact canonical match", "B": "near-duplicate match", "C": "shared component/fault anchors", "D": "nearest text only"}[rung],
            "evidence_note": "Single-cluster alternatives remain visible and are labelled Limited historical evidence.",
            "historical_agreement_probability": agreement,
            "calibration_source": "frozen_dev_fitted_rq5_logistic",
            "reranker_used": False,
            "candidate_split": "train",
            "model_components": query_components,
            "model_faults": query_faults,
            "derived_components": query_components,
            "derived_faults": query_faults,
            "target_location": " / ".join(query_locations),
            "partial_structure_warning": "Corpus structure comes from frozen Selective SpERT predictions; a new query uses the deterministic protected-token adapter.",
            "model_input": query_key,
            "input_adapter": "selective_canonical_problem_key",
            "input_adapted": query_key != canonical_problem_key(query),
            "normalized_interpretation": query_display,
            "normalization_model_input": query,
            "normalization_method": "protected_rules_then_canonical_key",
            "normalization_warning": "Numbers and directional anchors are preserved; no neural rewrite is accepted in the default hosted profile.",
            "normalization_model": "none_required_frozen_artifact_profile",
            "semantic_branch_used": False,
            "semantic_status": "precomputed_corpus_spert_query_adapter",
            "semantic_warning": "Corpus structure is frozen Selective SpERT output; this new query uses the deterministic adapter.",
            "semantic_entities": query_entities,
            "semantic_relations": [],
            "semantic_components": query_components,
            "semantic_faults": query_faults,
            "semantic_locations": query_locations,
            "rq4_entities": query_entities,
            "rq4_relations": [],
            "rq4_components": query_components,
            "rq4_faults": query_faults,
            "rq4_structure_source": "selective_canonical_bm25",
            "rq4_live_validated": False,
            "compound_detected": False,
            "decomposition_source": "disabled_no_procedure_synthesis",
            "subproblems": [],
        }
