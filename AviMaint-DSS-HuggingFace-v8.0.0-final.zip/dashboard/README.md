---
title: AviMaint DSS
emoji: ✈️
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 7860
pinned: false
---

# AviMaint-DSS

Deployment-ready dashboard for the frozen Selective-ByT5 RQ4/RQ5 system.

The default `frozen_artifacts` profile needs no neural weights. It serves the final normalized corpus, precomputed Selective SpERT structure, canonical BM25 retrieval, the DEV-selected `tau = 0.15` family vote, and frozen RQ5 calibration parameters.

Build locally:

```bash
docker build -t avimaint-dss .
docker run --rm -p 7860:7860 avimaint-dss
```

On Windows, start Docker Desktop and run `START_DASHBOARD.bat`. It verifies the frozen files, builds the image, and serves the dashboard at `http://127.0.0.1:7860`.

Verify before deployment:

```bash
python scripts/verify_release.py
```

No model folders need to be copied for this release. The two exact optional checkpoints are documented in `models/manifest.json` only for a future live-inference profile; this dashboard does not load them.

Deploy on Hugging Face Spaces:

1. Create a new Space and choose the **Docker** SDK.
2. Copy the contents of this folder to the root of the Space repository.
3. Commit and push. The container serves the frontend and API together on port `7860`.

Required runtime artifacts are already under `data/`: the 6,169-row frozen Selective corpus, the 6,169 problem-only Selective SpERT predictions, the final split and selection locks, the frozen RQ4 result, and the RQ5 calibrator parameters.
