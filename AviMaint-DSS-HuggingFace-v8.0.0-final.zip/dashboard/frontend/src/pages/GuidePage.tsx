import { BookOpenCheck, CircleHelp, GitBranch, Search, ShieldCheck } from "lucide-react";
import { Notice, PageHeader, Section } from "../components/ui";

export function GuidePage() {
  return (
    <>
      <PageHeader eyebrow="How to interpret the system" title="AviMaint-DSS guide" description="A concise reference for the frozen Selective representation, problem-only retrieval, evidence tiers, and safe use of historical maintenance evidence." />
      <div className="guide-grid">
        <Section title="Diagnose workflow">
          <ol className="flow-steps">
            <li><span>1</span><div><Search size={19} /><b>Problem text only</b><p>The query action is never used to retrieve supporting cases.</p></div></li>
            <li><span>2</span><div><GitBranch size={19} /><b>One Selective representation</b><p>The dashboard uses the same Selective normalized corpus and precomputed Selective SpERT structure as the final RQ4/RQ5 run.</p></div></li>
            <li><span>3</span><div><BookOpenCheck size={19} /><b>Cluster-distinct TRAIN history</b><p>Canonical BM25 retrieves problem evidence, then actions are opened and grouped from independent evidence clusters.</p></div></li>
            <li><span>4</span><div><ShieldCheck size={19} /><b>All evidence stays visible</b><p>Single-cluster alternatives are labelled Limited; negative and mixed cases are separated but never hidden.</p></div></li>
          </ol>
        </Section>
        <Section title="Evidence tiers">
          <div className="tier-list">
            <div className="strong"><b>Strong historical evidence</b><p>Multiple independent clusters and a clear action-family margin.</p></div>
            <div className="moderate"><b>Moderate historical evidence</b><p>Corroborated historical support with a smaller margin.</p></div>
            <div className="limited"><b>Limited historical evidence</b><p>Exactly one grounded cluster. It remains visible as a traceable example and is never presented as corroborated.</p></div>
            <div className="exploratory"><b>Exploratory evidence</b><p>Related historical evidence exists but does not justify a primary action.</p></div>
            <div className="abstain"><b>Nearest cases only</b><p>The system abstains and exposes cases for manual inspection.</p></div>
          </div>
        </Section>
      </div>
      <Section title="What every Diagnose result exposes" description="Use these fields together; no single score replaces engineering review.">
        <div className="guide-features">
          <div><b>Raw and normalized text</b><p>Normalized text drives readable display; raw text remains available for source verification.</p></div>
          <div><b>Entities and relations</b><p>Shows structured components, faults, locations, observations, and their indexed connections.</p></div>
          <div><b>Two grouping levels</b><p>Leakage groups protect the research split; exact evidence clusters control voting. Readable dashboard groups never change either one.</p></div>
          <div><b>Historical agreement</b><p>RQ5 calibration estimates action-family agreement in recorded data, never technical correctness.</p></div>
          <div><b>Source work orders</b><p>Every displayed action stays linked to record and cluster identifiers.</p></div>
          <div><b>Negative evidence</b><p>Failed, mixed, diagnostic-only, or unresolved historical actions remain visible and separated.</p></div>
        </div>
      </Section>
      <Notice kind="warning" title="The system does not authorise work">
        AviMaint-DSS does not select approved maintenance data, determine airworthiness, certify applicability, generate a maintenance procedure, approve parts, satisfy regulatory requirements, or release an aircraft to service.
      </Notice>
      <Section title="Recommended review sequence">
        <div className="review-sequence"><span>1. Confirm the interpreted problem</span><span>2. Check each compound issue separately</span><span>3. Read evidence tier and support</span><span>4. Inspect alternatives and negative cases</span><span>5. Verify source records</span><span>6. Consult current approved data</span></div>
      </Section>
      <div className="help-callout"><CircleHelp size={24} /><div><b>When evidence feels too confident</b><p>Do not act on it. Capture the query and visible provenance, then include it in the end-to-end diagnostic review.</p></div></div>
    </>
  );
}
