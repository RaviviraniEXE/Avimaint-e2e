from __future__ import annotations

import re
from dataclasses import dataclass
from difflib import SequenceMatcher

import numpy as np
from rank_bm25 import BM25Okapi

from .calibration import AgreementCalibrator
from .data_store import DataStore
from .settings import Settings
from .terminology import (
    canonical_problem_key,
    find_components,
    issue_family,
    looks_truncated,
    normalized_locations,
    normalize_query_for_display,
    target_component,
)


_TOKEN = re.compile(r"[a-z0-9_]+")


def tokenize(value: str) -> list[str]:
    return _TOKEN.findall(str(value or "").lower())


@dataclass(frozen=True)
class Hit:
    idx: int
    score: float
    raw_score: float
    match_level: str = "broader"
    rank_score: float = 0.0


class SelectiveRetriever:
    def __init__(self, store: DataStore, settings: Settings, calibrator: AgreementCalibrator):
        self.store = store
        self.settings = settings
        self.calibrator = calibrator
        self.docs = store.train["problem_norm"].astype(str).tolist()
        self.bm25 = BM25Okapi([tokenize(value) for value in self.docs])

    def search(self, query_key: str, top_k: int | None = None) -> list[Hit]:
        depth = int(top_k or self.settings.retrieval_depth)
        raw = np.asarray(self.bm25.get_scores(tokenize(query_key)), dtype=float)
        minimum = float(raw.min()) if raw.size else 0.0
        maximum = float(raw.max()) if raw.size else 0.0
        scores = (raw - minimum) / (maximum - minimum) if maximum - minimum > 1e-12 else np.zeros_like(raw)
        hits: list[Hit] = []
        used_clusters: set[str] = set()
        for idx in np.argsort(-scores):
            cluster = str(self.store.train.iloc[int(idx)].cluster_id)
            if cluster in used_clusters:
                continue
            used_clusters.add(cluster)
            hits.append(Hit(int(idx), float(scores[idx]), float(raw[idx])))
            if len(hits) >= depth:
                break
        return hits

    @staticmethod
    def _case(row, score: float, match_level: str = "broader") -> dict:
        return {
            "ident": str(row.ident),
            "problem": str(row.problem),
            "problem_raw": str(row.problem_raw),
            "problem_may_be_truncated": looks_truncated(str(row.problem)),
            "action": str(row.action),
            "action_raw": str(row.action_raw),
            "action_may_be_truncated": looks_truncated(str(row.action)),
            "action_family": str(row.action_family),
            "outcome": str(row.outcome),
            "cluster_id": str(row.cluster_id),
            "score": round(float(score), 8),
            "text_score": round(float(score), 8),
            "structure_score": 0.0,
            "channels": {"canonical_bm25": round(float(score), 8)},
            "match_level": match_level,
        }

    @staticmethod
    def _action_sentence(family: str, target: str) -> str:
        verb = {
            "Replace": "Replace", "Repair": "Repair", "Inspect": "Inspect",
            "Adjust": "Adjust", "Service": "Service", "Diagnose": "Diagnose",
            "Calibrate": "Calibrate",
        }.get(family, "Review")
        subject = target or "reported component"
        return f"{verb} the {subject}."

    @staticmethod
    def _contextual_action_target(action_target: str, query_component: str, family: str) -> str:
        if action_target == "gasket" and family in {"Replace", "Repair", "Inspect"}:
            if query_component.endswith("gasket"):
                return query_component
            if query_component in {"intake", "rocker cover"}:
                return f"{query_component} gasket"
        return action_target or query_component

    @staticmethod
    def _match_signature(row, query_component: str, query_faults: list[str], query_locations: list[str]) -> tuple[bool, float, str]:
        candidate_component = target_component(list(row.components))
        component_match = bool(query_component) and candidate_component == query_component
        fault_match = bool(query_faults) and bool(set(query_faults) & set(row.faults))
        location_match = set(row.locations) == set(query_locations)
        matched = int(component_match) + int(fault_match) + int(location_match)
        strict = component_match and fault_match and location_match
        label = "same component, fault and location" if strict else f"{matched}/3 anchors matched"
        return strict, matched / 3.0, label

    def search_operational(
        self,
        query_key: str,
        query_components: list[str],
        query_faults: list[str],
        query_locations: list[str],
        top_k: int,
    ) -> tuple[list[Hit], list[Hit]]:
        raw = np.asarray(self.bm25.get_scores(tokenize(query_key)), dtype=float)
        minimum = float(raw.min()) if raw.size else 0.0
        maximum = float(raw.max()) if raw.size else 0.0
        scores = (raw - minimum) / (maximum - minimum) if maximum - minimum > 1e-12 else np.zeros_like(raw)
        query_component = target_component(query_components)
        ranked: list[Hit] = []
        for idx, score in enumerate(scores):
            row = self.store.train.iloc[idx]
            strict, anchor_score, label = self._match_signature(
                row, query_component, query_faults, query_locations
            )
            length_gap = max(0, len(tokenize(self.docs[idx])) - len(tokenize(query_key)))
            operational_score = float(score) + anchor_score - min(0.20, length_gap * 0.01)
            ranked.append(Hit(idx, float(score), float(raw[idx]), label, operational_score))
        ranked.sort(key=lambda hit: (-hit.rank_score, -hit.score, hit.idx))

        strict_hits: list[Hit] = []
        nearest_hits: list[Hit] = []
        used_strict: set[str] = set()
        used_nearest: set[str] = set()
        for hit in ranked:
            cluster = str(self.store.train.iloc[hit.idx].cluster_id)
            if cluster not in used_nearest and len(nearest_hits) < 10:
                used_nearest.add(cluster)
                nearest_hits.append(hit)
            if hit.match_level == "same component, fault and location" and cluster not in used_strict:
                used_strict.add(cluster)
                strict_hits.append(hit)
                if len(strict_hits) >= top_k and len(nearest_hits) >= 10:
                    break
        return strict_hits, nearest_hits

    @staticmethod
    def _distinct_clusters(examples: list[dict], limit: int) -> list[dict]:
        selected = []
        used = set()
        for example in examples:
            cluster = example["cluster_id"]
            if cluster in used:
                continue
            used.add(cluster)
            selected.append(example)
            if len(selected) >= limit:
                break
        return selected

    def _aggregate(self, hits: list[Hit], query_components: list[str], query_faults: list[str]) -> dict:
        patterns: dict[str, dict] = {}
        negative_patterns: dict[str, set[str]] = {}
        negative: list[dict] = []
        expanded_seen: set[int] = set()
        for hit in hits:
            cluster = str(self.store.train.iloc[hit.idx].cluster_id)
            for idx in self.store.cluster_members.get(cluster, [hit.idx]):
                if idx in expanded_seen:
                    continue
                expanded_seen.add(idx)
                row = self.store.train.iloc[idx]
                family = str(row.action_family)
                outcome = str(row.outcome)
                query_component = target_component(query_components)
                action_target = target_component(find_components(str(row.action))) or target_component(list(row.components))
                action_target = self._contextual_action_target(action_target, query_component, family)
                pattern_key = f"{family}|{action_target}"
                example = self._case(row, hit.score, hit.match_level)
                if outcome in {"negative", "mixed"}:
                    negative.append(example)
                    if family != "Other":
                        negative_patterns.setdefault(pattern_key, set()).add(cluster)
                    continue
                if family == "Other":
                    continue
                bucket = patterns.setdefault(pattern_key, {
                    "family": family, "target": action_target, "clusters": {},
                    "outcomes": {}, "examples": [],
                })
                bucket["clusters"][cluster] = max(bucket["clusters"].get(cluster, 0.0), hit.score)
                bucket["outcomes"].setdefault(outcome, set()).add(cluster)
                bucket["examples"].append(example)

        rows = []
        for pattern_key, bucket in patterns.items():
            family = bucket["family"]
            support = len(bucket["clusters"])
            prior = max(self.store.family_priors.get(family, 0.0), 1e-12)
            rows.append({
                "family": family,
                "action_target": bucket["target"],
                "suggestion": self._action_sentence(family, bucket["target"]),
                "support_clusters": support,
                "case_count": len(bucket["examples"]),
                "score_sum": float(sum(bucket["clusters"].values())),
                "prior": prior,
                "adjusted_support": support / (prior ** self.settings.selected_tau),
                "outcome_positive": len(bucket["outcomes"].get("positive", set())),
                "outcome_unknown": len(bucket["outcomes"].get("unknown", set())),
                "outcome_negative": len(negative_patterns.get(pattern_key, set())),
                "examples": self._distinct_clusters(
                    sorted(bucket["examples"], key=lambda item: (-item["score"], item["ident"])), 8
                ),
            })
        # Operational presentation ranks repeated exact-match action patterns first.
        # The frozen RQ4 family vote and its metrics remain unchanged in research artifacts.
        rows.sort(key=lambda item: (-item["support_clusters"], -item["adjusted_support"], -item["score_sum"], -item["outcome_positive"], item["family"], item["action_target"]))
        top = rows[0]["support_clusters"] if rows else 0.0
        second = rows[1]["support_clusters"] if len(rows) > 1 else 0.0
        return {
            "patterns": rows,
            "negative": sorted(negative, key=lambda item: (-item["score"], item["ident"])),
            "family_margin": float(top - second),
        }

    def recommend(self, query: str, top_k: int = 50) -> dict:
        query = str(query or "").strip()
        query_display = normalize_query_for_display(query)
        query_key = canonical_problem_key(query_display)
        query_components = find_components(query_display)
        query_fault = issue_family(query_display)
        query_faults = [query_fault] if query_fault else []
        query_locations = normalized_locations(query_display)
        query_component = target_component(query_components)
        query_entities = (
            [{"type": "MAINT_ITEM", "text": value, "score": 1.0} for value in query_components]
            + [{"type": "FAULT", "text": value, "score": 1.0} for value in query_faults]
            + [{"type": "LOC", "text": value, "score": 1.0} for value in query_locations]
        )
        hits, nearest_hits = self.search_operational(
            query_key,
            query_components,
            query_faults,
            query_locations,
            min(max(int(top_k), 5), 100),
        )
        evidence = self._aggregate(hits, query_components, query_faults)
        nearest = [
            self._case(self.store.train.iloc[hit.idx], hit.score, hit.match_level)
            for hit in nearest_hits
        ]
        patterns = evidence["patterns"]
        primary = patterns[0] if patterns else None
        support = int(primary["support_clusters"]) if primary else 0
        top_score = nearest_hits[0].score if nearest_hits else 0.0
        second_score = nearest_hits[1].score if len(nearest_hits) > 1 else 0.0
        retrieval_margin = float(top_score - second_score)
        exact = any(self.docs[hit.idx] == query_key for hit in hits)
        near = any(SequenceMatcher(None, query_key, self.docs[hit.idx]).ratio() >= 0.87 for hit in hits[:10])
        rung = "A" if exact else "B" if near else "C" if hits else "D"
        support_tier = "strong" if support >= 3 else "moderate" if support == 2 else "limited" if support == 1 else "nearest_cases_only"
        badge = support_tier if primary else "abstain"
        component_label = query_component or "reported component"
        family_label = primary["family"] if primary else ""
        statement = primary["suggestion"] if primary else ""
        strategies = []
        for index, pattern in enumerate(patterns):
            strategies.append({
                "family": pattern["family"],
                "action_target": pattern["action_target"],
                "sentence": pattern["suggestion"],
                "meaning": f"Recorded for the same component, fault and location in {pattern['support_clusters']} independent evidence cluster(s) and {pattern['case_count']} work order(s).",
                "support_clusters": pattern["support_clusters"],
                "case_count": pattern["case_count"],
                "outcome_positive": pattern["outcome_positive"],
                "outcome_negative": pattern["outcome_negative"],
                "outcome_unknown": pattern["outcome_unknown"],
                "examples": [
                    {
                        "ident": example["ident"],
                        "action": example["action"],
                        "outcome": example["outcome"],
                        "source_may_be_truncated": example["action_may_be_truncated"],
                    }
                    for example in pattern["examples"][:5]
                ],
                "is_primary": index == 0,
                "tier": "single_case" if pattern["support_clusters"] == 1 else "corroborated",
            })
        recommended = primary["examples"][:10] if primary else []
        # The frozen RQ5 calibrator was fitted to the frozen family-vote feature
        # distribution. It must not be presented as calibrated for this stricter
        # operational action-pattern layer.
        agreement = None
        if hits and (query_components or query_faults):
            top_row = self.store.train.iloc[hits[0].idx]
            component_match = int(target_component(list(top_row.components)) == query_component)
            fault_match = int(bool(set(query_faults) & set(top_row.faults)))
            location_match = int(set(query_locations) == set(top_row.locations))
            anchor_coverage = (component_match + fault_match + location_match) / 3.0
        else:
            anchor_coverage = 0.0
        return {
            "query": query,
            "components": query_components,
            "faults": query_faults,
            "badge": badge,
            "lens": "problem_only_selective_history",
            "headline_action": family_label,
            "headline_reason": f"Most frequent action pattern across {support} exact anchor-matched evidence cluster(s). Repeated patterns rank first; one-cluster patterns remain visible below." if primary else "No historical action matched the same component, fault and location. Broader nearest cases are shown without an action suggestion.",
            "support_clusters": support,
            "structured_sentence": statement,
            "strategies": strategies,
            "recommended_cases": recommended,
            "alternatives": strategies[1:],
            "nearest_cases": nearest,
            "negative_evidence": evidence["negative"][:10],
            "structure_source": "selective_query_adapter",
            "entities": query_entities,
            "relations": [],
            "family_evidence_margin": evidence["family_margin"],
            "retrieval_margin": retrieval_margin,
            "anchor_coverage": anchor_coverage,
            "abstain": not bool(primary),
            "evidence_family": family_label,
            "base_top_score": top_score,
            "evidence_tier": {"A": "exact canonical problem", "B": "near-duplicate with exact anchors", "C": "same component, fault and location", "D": "broader nearest cases only"}[rung],
            "evidence_note": "Operational suggestions require the same component, fault and location. Single-cluster action patterns remain visible as limited evidence.",
            "historical_agreement_probability": agreement,
            "calibration_source": "not_applied_to_operational_exact_anchor_layer",
            "reranker_used": True,
            "candidate_split": "train",
            "model_components": query_components,
            "model_faults": query_faults,
            "derived_components": query_components,
            "derived_faults": query_faults,
            "target_location": " / ".join(query_locations),
            "partial_structure_warning": "Corpus structure comes from frozen Selective SpERT predictions; the new query uses the deterministic protected-token adapter and exact operational anchor matching.",
            "model_input": query_key,
            "input_adapter": "selective_canonical_problem_key",
            "input_adapted": query_key != canonical_problem_key(query),
            "normalized_interpretation": query_display,
            "normalization_model_input": query,
            "normalization_method": "protected_rules_then_canonical_key",
            "normalization_warning": "Numbers and directional anchors are preserved; no neural rewrite is accepted in the default hosted profile.",
            "normalization_model": "none_required_frozen_artifact_profile",
            "semantic_branch_used": False,
            "semantic_status": "precomputed_corpus_spert_query_adapter",
            "semantic_warning": "Corpus structure is frozen Selective SpERT output; this new query uses the deterministic adapter.",
            "semantic_entities": query_entities,
            "semantic_relations": [],
            "semantic_components": query_components,
            "semantic_faults": query_faults,
            "semantic_locations": query_locations,
            "rq4_entities": query_entities,
            "rq4_relations": [],
            "rq4_components": query_components,
            "rq4_faults": query_faults,
            "rq4_structure_source": "frozen_selective_canonical_bm25_plus_operational_exact_anchor_filter",
            "rq4_live_validated": False,
            "compound_detected": False,
            "decomposition_source": "disabled_no_procedure_synthesis",
            "subproblems": [],
            "operational_match_policy": "same target component + same fault + same normalized location set",
            "matching_signature": {
                "component": query_component,
                "fault": query_fault or "",
                "locations": query_locations,
            },
            "exact_match_clusters": len(hits),
        }
