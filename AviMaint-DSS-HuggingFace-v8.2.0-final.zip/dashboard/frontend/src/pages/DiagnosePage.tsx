import { useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  Braces,
  Check,
  ClipboardPlus,
  FileSearch,
  Plane,
  Search,
  ShieldCheck,
} from "lucide-react";
import { api } from "../api/client";
import type {
  CaseEvidence,
  DiagnoseResponse,
  Entity,
  Recommendation,
  Relation,
  Strategy,
} from "../api/types";
import {
  Definition,
  EmptyState,
  ErrorState,
  EvidenceBadge,
  Notice,
  PageHeader,
  Section,
  Tag,
} from "../components/ui";
import {
  badgeLabel,
  getEntityText,
  getEntityType,
  loadWatchlist,
  percent,
  recommendationToWatchlist,
  saveWatchlist,
  score,
} from "../utils";

const examples = [
  { label: "Recurring intake", query: "Number 2 intake leaking." },
  { label: "Low compression", query: "Left-hand engine number 2 cylinder has low compression." },
  { label: "Mixed outcome", query: "ENGINE OVER RIDE SPEED WAS 1225 RPM." },
  { label: "Specific gasket", query: "Number 4 intake gasket leaking." },
  { label: "Weak / unseen", query: "NOISE AND INTERMITTENT VIBRATION FROM AN UNIDENTIFIED ENGINE AREA." },
];

export function DiagnosePage() {
  const [query, setQuery] = useState("Number 2 intake leaking.");
  const [response, setResponse] = useState<DiagnoseResponse | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event?: React.FormEvent) {
    event?.preventDefault();
    if (!query.trim() || busy) return;
    setBusy(true);
    setError("");
    try {
      setResponse(await api.diagnose(query.trim()));
    } catch (reason) {
      setResponse(null);
      setError(reason instanceof Error ? reason.message : "Diagnosis failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <PageHeader eyebrow="Operational evidence matching" title="Diagnose with historical evidence" description="Describe the problem only. Action suggestions require the same component, fault and location; repeated historical actions rank first and one-case actions remain visible as limited evidence." />
      <form className="diagnose-form" onSubmit={submit}>
        <div className="query-box">
          <Plane size={23} />
          <textarea aria-label="Maintenance problem" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="e.g. LEFT MAGNETO RPM DROP ON RUN UP" rows={3} maxLength={5000} />
          <button className="button primary diagnose-button" type="submit" disabled={!query.trim() || busy}>
            {busy ? <><span className="button-spinner" /> Analysing…</> : <><Search size={18} /> Diagnose</>}
          </button>
        </div>
        <div className="example-row"><span>Representative tests</span>{examples.map((item) => <button key={item.label} type="button" onClick={() => setQuery(item.query)}>{item.label}</button>)}</div>
      </form>
      <Notice kind="warning" title="Operational boundary">
        Results are historical planning evidence—not a maintenance instruction, airworthiness finding, regulatory approval, or probability of technical correctness.
      </Notice>
      {busy && <AnalysisProgress />}
      {error && <ErrorState message={error} retry={() => void submit()} />}
      {!busy && !error && !response && <EmptyState title="Ready for a problem description" detail="Run one of the representative tests or enter a problem from a current planning scenario." />}
      {!busy && response && <DiagnoseResult response={response} />}
    </>
  );
}

function AnalysisProgress() {
  return (
    <div className="analysis-progress" role="status">
      <div className="radar"><span /><span /><i /></div>
          <div><strong>Matching historical evidence</strong><p>Protecting identifiers, retrieving TRAIN clusters, enforcing component–fault–location agreement, and ranking recorded action patterns.</p></div>
    </div>
  );
}

function DiagnoseResult({ response }: { response: DiagnoseResponse }) {
  const result = response.result;
  return (
    <div className="diagnose-results">
      <Interpretation result={result} />
      {result.compound_detected && result.subproblems.length > 0 ? (
        <>
          <Notice title={`${result.subproblems.length} independently grounded issues detected`}>
            Each subproblem below received a separate retrieval and evidence decision. No combined procedure was invented. Decomposition source: <b>{result.decomposition_source || "structured relations"}</b>.
          </Notice>
          <div className="subproblem-stack">
            {result.subproblems.map((item) => (
              <section className="subproblem" key={`${item.index}-${item.query}`}>
                <div className="subproblem-head">
                  <span>Issue {item.index}</span><h2>{item.title}</h2><p>{item.query}</p>
                  <div className="tag-row"><Tag>{item.component || "Unspecified component"}</Tag>{item.location && <Tag tone="slate">{item.location}</Tag>}<Tag tone="rose">{item.issue || item.issue_type}</Tag></div>
                </div>
                <RecommendationView result={item.recommendation} compact />
              </section>
            ))}
          </div>
          <CasesSection title="Combined-query nearest cases" description="Shown only for research transparency; per-issue evidence above remains authoritative." cases={result.nearest_cases} />
        </>
      ) : (
        <RecommendationView result={result} />
      )}
      <Section title="Model and retrieval provenance" description="Inspect what each branch received and which safeguards were active.">
        <div className="provenance-grid">
          <Definition term="User input"><code>{result.query}</code></Definition>
          <Definition term="Protected readable interpretation"><code>{result.normalized_interpretation || result.query}</code></Definition>
          <Definition term="Canonical retrieval key"><code>{result.model_input || "Not reported"}</code></Definition>
          <Definition term="Corpus structure">Frozen Selective SpERT predictions</Definition>
          <Definition term="Normalization method">{result.normalization_method || "none"}</Definition>
          <Definition term="Evidence library">{response.meta.candidate_split.toUpperCase()} only</Definition>
          <Definition term="Retrieval base">{response.meta.rq4_base}</Definition>
          <Definition term="Reranker role">{response.meta.reranker_role.replaceAll("_", " ")}</Definition>
        </div>
        {(result.normalization_warning || result.semantic_warning || result.partial_structure_warning) && (
          <div className="warning-list">
            {[result.normalization_warning, result.semantic_warning, result.partial_structure_warning].filter(Boolean).map((warning) => <p key={warning}><AlertTriangle size={16} />{warning}</p>)}
          </div>
        )}
      </Section>
    </div>
  );
}

function Interpretation({ result }: { result: Recommendation }) {
  const anchors = [...result.model_components, ...result.model_faults];
  return (
    <Section className="interpretation-card">
      <div className="interpretation-title"><div><span className="eyebrow">Protected query interpretation</span><h2>{result.normalized_interpretation || result.query}</h2></div><Tag tone="green">Exact-anchor operational query</Tag></div>
      <div className="anchor-row"><b>Primary anchors</b>{anchors.length ? anchors.map((item, index) => <Tag key={`${item}-${index}`}>{item}</Tag>) : <span>No learned anchor predicted</span>}</div>
      <details className="details-panel"><summary><Braces size={17} /> Inspect extracted entities and relations</summary><StructurePayload entities={result.entities} relations={result.relations} /></details>
      <details className="details-panel"><summary><FileSearch size={17} /> Validated RQ4 representation</summary><StructurePayload entities={result.rq4_entities} relations={result.rq4_relations} /></details>
    </Section>
  );
}

function RecommendationView({ result, compact = false }: { result: Recommendation; compact?: boolean }) {
  const [added, setAdded] = useState(false);
  const canPromote = Boolean(result.structured_sentence && !result.abstain);
  const actionSet = result.action_set?.length ? result.action_set : result.strategies;
  function addToPlanning() {
    const current = loadWatchlist();
    saveWatchlist([recommendationToWatchlist(result), ...current].slice(0, 100));
    window.dispatchEvent(new Event("avimaint-watchlist"));
    setAdded(true);
  }
  return (
    <div className={compact ? "recommendation compact" : "recommendation"}>
      <Section className={`decision-card ${result.badge}`}>
        <div className="decision-top">
          <EvidenceBadge badge={result.badge} />
          <div className="decision-metrics">
            <span><b>{result.support_clusters}</b> independent clusters</span>
            <span><b>{percent(result.anchor_coverage)}</b> operational anchors</span>
            <span><b>{result.full_structure_match_clusters || 0}</b> full graph-match clusters</span>
            <span><b>{result.historical_agreement_probability == null ? "not applied" : percent(result.historical_agreement_probability, 1)}</b> RQ5 family calibration</span>
          </div>
        </div>
        {result.structured_sentence ? (
          <div className="primary-action">
            <ArrowRight size={25} />
            <div className="action-set-block">
              <small>Evidence-backed action set</small>
              <h2>{result.structural_match_label || "Matching historical actions"}</h2>
              <p>{result.headline_reason}</p>
              <div className="green-action-set">
                {actionSet.map((strategy, index) => (
                  <div className={`green-action ${strategy.tier === "single_case" ? "limited" : ""}`} key={`${strategy.family}-${strategy.action_target || strategy.sentence}-${index}`}>
                    <span className="action-number">{index + 1}</span>
                    <div>
                      <b>{strategy.sentence}</b>
                      <small>{strategy.is_primary ? "Primary · most repeated" : strategy.category === "assessment" ? "Separately observed assessment/check" : strategy.tier === "single_case" ? "Alternative · one-cluster evidence" : "Supported alternative"}</small>
                    </div>
                    <em>{strategy.full_structure_support_clusters || 0} full graph · {strategy.support_clusters} operational cluster{strategy.support_clusters === 1 ? "" : "s"} · {strategy.case_count} case{strategy.case_count === 1 ? "" : "s"}</em>
                  </div>
                ))}
              </div>
              <p className="action-set-note">{result.action_set_note}</p>
              {result.graph_coverage_note && <p className="action-set-note"><b>Structure scope:</b> {result.graph_coverage_note}</p>}
            </div>
          </div>
        ) : (
          <div className="abstention"><ShieldCheck size={27} /><div><h2>No primary action passed the evidence gate</h2><p>{result.headline_reason || `Closest historical action family: ${result.evidence_family || "none"}. Review the nearest cases without treating them as a recommendation.`}</p></div></div>
        )}
        {result.badge === "limited" && <Notice kind="warning"><b>One-cluster evidence.</b> This is a traceable historical example, not a recurring strategy.</Notice>}
        <div className="technical-strip">
          <span>Evidence tier <b>{result.evidence_tier || badgeLabel[result.badge]}</b></span>
          <span>Relation equality <b>{result.relation_match_evaluated ? "evaluated" : "not claimed"}</b></span>
          <span>Top relative text match <b>{score(result.base_top_score)}</b></span>
          <span>Support lead <b>{score(result.family_evidence_margin)}</b> clusters</span>
          <span>Library <b>{result.candidate_split.toUpperCase()}</b></span>
        </div>
        {canPromote && <button className="button secondary planning-add" type="button" onClick={addToPlanning} disabled={added}>{added ? <><Check size={17} /> Added to planning</> : <><ClipboardPlus size={17} /> Add to planning watchlist</>}</button>}
      </Section>
      {result.strategies.length > 0 && (
        <Section title="Evidence details for matched actions" description="The green action set keeps every matched action visible. These cards preserve its independent support and source work orders; they do not imply an action sequence.">
          <div className="strategy-grid">{result.strategies.map((strategy) => <StrategyCard strategy={strategy} key={`${strategy.family}-${strategy.action_target || strategy.sentence}-${strategy.tier}`} />)}</div>
        </Section>
      )}
      <CasesSection title="Exact-match supporting work orders" description="Cases supporting the displayed action pattern, diversified by independent evidence cluster." cases={result.recommended_cases} />
      {result.negative_evidence.length > 0 && <CasesSection negative title="Negative or unresolved evidence" description="Preserved for transparency and excluded from positive action-family support." cases={result.negative_evidence} />}
      <CasesSection title="Broader nearest historical cases" description="Shown for transparency. Cases that do not match all three anchors do not contribute to the action suggestion." cases={result.nearest_cases} />
    </div>
  );
}

function StrategyCard({ strategy }: { strategy: Strategy }) {
  return (
    <article className={`strategy-card ${strategy.tier === "single_case" ? "weak" : ""}`}>
      <div className="strategy-heading"><div><span>{strategy.tier === "single_case" ? "Limited · one-cluster action" : "Repeated historical action"}</span><h3>{strategy.sentence}</h3></div>{strategy.is_primary && <Tag tone="green">Primary</Tag>}</div>
      <p className="strategy-sentence">Action family: {strategy.family}{strategy.action_target ? ` · target: ${strategy.action_target}` : ""}</p><p>{strategy.meaning}</p>
      <div className="strategy-stats"><span><b>{strategy.support_clusters}</b> clusters</span><span><b>{strategy.case_count}</b> cases</span><span className="positive-text"><b>{strategy.outcome_positive}</b> positive</span><span className="negative-text"><b>{strategy.outcome_negative}</b> neg./mixed</span></div>
      {strategy.examples.length > 0 && <details><summary>Recorded examples</summary>{strategy.examples.map((example) => <div className="strategy-example" key={`${example.ident}-${example.action}`}><b>{example.ident}</b><span>{example.action}</span><em>{example.outcome}{example.source_may_be_truncated ? " · truncated source" : ""}</em></div>)}</details>}
    </article>
  );
}

function CasesSection({ title, description, cases, negative = false }: { title: string; description: string; cases: CaseEvidence[]; negative?: boolean }) {
  if (!cases.length) return null;
  return (
    <Section title={title} description={description} className={negative ? "negative-section" : ""}>
      <div className="case-list">{cases.map((item, index) => <CaseCard item={item} rank={index + 1} key={`${item.ident}-${item.cluster_id}-${index}`} />)}</div>
    </Section>
  );
}

function CaseCard({ item, rank }: { item: CaseEvidence; rank: number }) {
  return (
    <details className="case-card">
      <summary>
        <span className="case-rank">{rank}</span>
        <div className="case-summary"><b>{item.problem}</b><span>{item.action_family} · {item.outcome || "unknown outcome"}{item.match_level ? ` · ${item.match_level}` : ""}</span></div>
        <span className="case-score">{score(item.score)}</span>
      </summary>
      <div className="case-detail">
        {(item.problem_may_be_truncated || item.action_may_be_truncated) && <p className="source-warning">The source record appears truncated. Missing words were not inferred or completed.</p>}
        <div><span>Recorded action</span><p>{item.action || "No action text recorded"}</p></div>
        {item.problem_raw && item.problem_raw !== item.problem && <div><span>Original problem text</span><p>{item.problem_raw}</p></div>}
        {item.action_raw && item.action_raw !== item.action && <div><span>Original action text</span><p>{item.action_raw}</p></div>}
        <dl><Definition term="Source record">{item.ident}</Definition><Definition term="Evidence cluster">{item.cluster_id}</Definition><Definition term="Relative text score">{score(item.text_score)}</Definition><Definition term="Operational match">{item.match_level || "broader nearest case"}</Definition></dl>
      </div>
    </details>
  );
}

function StructurePayload({ entities, relations }: { entities: Entity[]; relations: Relation[] }) {
  return (
    <div className="structure-grid">
      <div><h4>Entities · {entities.length}</h4>{entities.length ? <div className="entity-list">{entities.map((entity, index) => <span key={index}><b>{getEntityType(entity)}</b>{getEntityText(entity)}</span>)}</div> : <p>No model entities returned.</p>}</div>
      <div><h4>Relations · {relations.length}</h4>{relations.length ? <div className="relation-list">{relations.map((relation, index) => <span key={index}>{String(relation.type ?? relation.label ?? "RELATION")}</span>)}</div> : <p>No model relations returned.</p>}</div>
    </div>
  );
}
