from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import app, runtime
from app.settings import settings
from app.terminology import canonical_problem_key, display_problem_key, find_components, merge_components, normalized_locations


def test_number_and_alias_keys_are_symmetric():
    assert canonical_problem_key("#2 INTAKES LEAKING") == canonical_problem_key("NUMBER TWO INTAKE LEAKING")
    assert display_problem_key("#2 INTAKE IS LEAKING") == display_problem_key("#2 INTAKE LEAKING")


def test_distinct_component_granularity_is_preserved():
    assert find_components("NUMBER 2 INTAKE GASKET LEAKING") == ["intake gasket"]
    assert find_components("NUMBER 2 INTAKE LEAKING") == ["intake"]


def test_component_plurals_collapse_without_merging_distinct_parts():
    assert find_components("ROCKER COVER GASKETS LEAKING") == ["rocker cover gasket"]
    assert merge_components(
        "ROCKER COVER GASKETS LEAKING",
        ["rocker cover gaskets", "rocker covers", "gasket"],
    ) == ["rocker cover gasket"]
    assert normalized_locations("#2 INTAKE LEAKING") == normalized_locations("NUMBER TWO INTAKE LEAKING") == ["num_2"]


def test_frozen_identity_and_prior_distribution():
    store, _calibrator, _retriever = runtime()
    assert len(store.df) == 6169
    assert len(store.train) == 4319
    assert abs(sum(store.family_priors.values()) - 1.0) < 1e-12
    assert 0.63 < store.family_priors["Replace"] < 0.65


def test_api_and_single_support_visibility():
    client = TestClient(app)
    assert client.get("/api/v1/health").status_code == 200
    response = client.post("/api/v1/diagnose", json={"query": "#2 intake leaking", "top_k": 50})
    assert response.status_code == 200
    payload = response.json()["result"]
    assert payload["candidate_split"] == "train"
    assert payload["strategies"]
    assert any(item["tier"] == "single_case" for item in payload["strategies"])
    assert payload["structured_sentence"] == "Replace the intake gasket."
    assert [item["sentence"] for item in payload["action_set"]] == [
        "Replace the intake gasket.",
        "Repair the intake gasket.",
    ]
    assert payload["action_set"][0]["role"] == "primary"
    assert payload["action_set"][1]["role"] == "limited_alternative"
    assert payload["action_set_sequence_supported"] is False
    assert payload["action_set_summary"] == (
        "Primary recorded option: Replace the intake gasket. "
        "Limited one-cluster alternative: Repair the intake gasket."
    )
    assert payload["matching_signature"] == {"component": "intake", "fault": "leak", "locations": ["num_2"]}
    assert payload["relation_match_evaluated"] is False
    assert payload["full_structure_match_clusters"] == 0
    assert payload["structural_match_label"] == "Complete operational signature match"
    assert payload["historical_agreement_probability"] is None
    assert all(item["match_level"] == "same component, fault and location" for item in payload["recommended_cases"])
    assert all("action" in item for item in payload["nearest_cases"])
    assert len({item["cluster_id"] for item in payload["recommended_cases"]}) == len(payload["recommended_cases"])


def test_full_graph_claim_requires_an_exact_frozen_train_problem():
    client = TestClient(app)
    response = client.post(
        "/api/v1/diagnose",
        json={"query": "NUMBER TWO CYLINDER INTAKE LEAKING.", "top_k": 50},
    )
    assert response.status_code == 200
    payload = response.json()["result"]
    assert payload["query_structure_source"] == "frozen_train_exact_text_prediction"
    assert payload["relation_match_evaluated"] is True
    assert payload["full_structure_match_clusters"] >= 1
    assert any(item["full_structure_support_clusters"] >= 1 for item in payload["action_set"])
    assert payload["entities"]
    assert payload["relations"]
    assert any(item["match_level"] == "full entity-relation match" for item in payload["nearest_cases"])


def test_every_dashboard_endpoint_uses_the_same_release():
    client = TestClient(app)
    overview = client.get("/api/v1/overview")
    assert overview.status_code == 200
    assert overview.json()["kpis"]["work_orders"] == 6169
    insights = client.get("/api/v1/insights")
    assert insights.status_code == 200
    component_names = {item["component"] for item in insights.json()["components"]}
    assert "rocker covers" not in component_names
    assert "rocker cover gaskets" not in component_names
    graph = client.get("/api/v1/knowledge-graph")
    assert graph.status_code == 200
    focused = client.get("/api/v1/knowledge-graph?focus_component=intake%20gasket&min_edge=1").json()
    assert focused["scope"]["label"].endswith("intake gasket")
    leak_node = next(node for node in focused["nodes"] if node["id"] == "fault:leak")
    leak_edge = next(edge for edge in focused["edges"] if edge["source"] == "component:intake gasket" and edge["target"] == "fault:leak")
    assert leak_node["count"] == leak_edge["count"]
    assert leak_node["count"] < 3116
    recurring = client.get("/api/v1/planning/recurring?min_support=1&limit=3")
    assert recurring.status_code == 200
    group_id = recurring.json()["items"][0]["cluster_id"]
    card = client.post("/api/v1/planning/job-card", json={"cluster_id": group_id})
    assert card.status_code == 200
    evaluation = client.get("/api/v1/evaluation")
    assert evaluation.status_code == 200
    assert evaluation.json()["frozen"]["rq4"]["selected_tau"] == 0.15
    expected_static_status = 200 if (settings.frontend_dist / "index.html").is_file() else 503
    assert client.get("/").status_code == expected_static_status
    assert client.get("/diagnose").status_code == expected_static_status
